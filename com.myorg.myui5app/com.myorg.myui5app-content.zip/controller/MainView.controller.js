sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("com.myorg.myui5app.controller.MainView",{onInit:function(){}})});
//# sourceMappingURL=MainView.controller.js.map